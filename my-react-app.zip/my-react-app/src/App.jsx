import ToDoList from "./ToDoList";

function App() {
  
  return(<ToDoList/>);

}

export default App
